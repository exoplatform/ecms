holiday business process for bonita
-----------------------------------

* What you need

- Maven 2 (http://maven.apache.org/)

- Java jdk 1.5


* How to build the BP

- You have to install the Bonita implementation artifact to your local Maven
  repository. For that simply run the following command :
  
mvn install:install-file -Dfile=exo-ecm.services.workflow.impl.bonita.standalone-1.0.jar -DgroupId=exo-ecm -DartifactId=exo-ecm.services.workflow.impl.bonita.standalone -Dversion=1.0 -Dpackaging=jar  -DgeneratePom=true


- run "mvn package"  (it will download some artifacts from the web)
  
- you'll find your business process packaged in a jar file in "target" directory.
  
  exo-ecm.business-process.holiday.bonita.standalone-1.0.jar


* Running the BP

- import the workflow package, for that refer to the "workflow portlets" 
  documentation for more details.
  
  ps: the extension of the business process archive does not matter. "jar" or "bpar" work
  the same, provided the format is "zip".


